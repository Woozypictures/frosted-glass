Glass Icon Pack APK extraction

Extracted 2069 square PNG image assets from res/drawable-nodpi-v4/.
Original filenames and image data are preserved; no resizing or recompression was performed.

The metadata folder contains the icon-pack mapping/catalog XML files:
- appfilter.xml: app/component-to-icon mappings
- drawable.xml: icon catalogue
- themeinfo.xml and themecfg.xml: theme metadata

Non-square image assets in drawable-nodpi-v4 were excluded from icons.
